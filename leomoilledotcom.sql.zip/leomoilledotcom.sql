-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : ven. 18 fév. 2022 à 15:14
-- Version du serveur : 5.7.33
-- Version de PHP : 7.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `leomoilledotcom`
--

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `postId` int(11) NOT NULL,
  `isApproved` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `commentDate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `comments`
--

INSERT INTO `comments` (`id`, `authorId`, `postId`, `isApproved`, `comment`, `commentDate`) VALUES
(24, 8, 11, 1, 'Superbe article. Bravo !', '2022-02-18 14:30:15'),
(25, 8, 10, 1, 'Un premier article très sympa !', '2022-02-18 14:31:36'),
(23, 5, 11, 1, 'Je me suis permis de modifier l\'article suite à une coquille.', '2022-02-18 14:26:09'),
(26, 8, 11, 0, 'Encore bravo !!', '2022-02-18 14:34:58');

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `authorId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `preContent` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `publicationDate` datetime NOT NULL,
  `modificationDate` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `posts`
--

INSERT INTO `posts` (`id`, `authorId`, `title`, `preContent`, `content`, `publicationDate`, `modificationDate`) VALUES
(10, 5, 'Titre placeholder', 'Nullam feugiat metus et justo faucibus, a viverra magna pellentesque. Sed erat lorem, auctor ac malesuada at, ullamcorper sed massa.', '## Lorem ipsum dolor sit amet\r\nconsectetur adipiscing elit. Donec sagittis accumsan magna vel faucibus. Maecenas eros ipsum, ultrices non dapibus eu, mollis nec ligula. Nunc a lobortis elit, non porta eros. Phasellus mollis ex ac sem sodales\r\n\r\n### Pulvinar tortor tempus\r\nProin venenatis neque ut condimentum ultrices. Quisque faucibus, lectus quis porta ultrices, metus massa porttitor mauris, ac iaculis elit massa non est. Ut tempor consectetur arcu eget dignissim. Nulla scelerisque porttitor orci eu vestibulum. In at arcu eget orci lobortis hendrerit. \r\n\r\n## Sed sollicitudin ligula turpis\r\nVitae laoreet arcu commodo eget. Aliquam eget bibendum purus. Fusce et cursus velit, nec iaculis magna. Duis dignissim, leo eu tristique dignissim, erat tellus vehicula risus, et volutpat sem risus sit amet ligula. Aenean efficitur facilisis sem quis porttitor. Nullam feugiat metus et justo faucibus, a viverra magna pellentesque. Sed erat lorem, auctor ac malesuada at, ullamcorper sed massa.', '2022-02-18 14:22:59', NULL),
(11, 5, 'Titre placeholder 2', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec sagittis accumsan magna.', '## Integer non urna non lectus maximus accumsan\r\nUt a ipsum lacus. Cras mollis leo id risus tincidunt placerat. Morbi eu arcu dignissim, elementum mi sollicitudin, pellentesque nibh. Donec eu accumsan velit. Vivamus congue tempus libero, non pulvinar orci pretium vel. Nunc gravida ante viverra justo consequat ultrices. Mauris id ante id metus bibendum lacinia pulvinar sit amet elit. Fusce risus libero, dignissim et ornare eget, tincidunt nec mi. Quisque nec nunc ut libero blandit tincidunt. Mauris suscipit dui enim, vitae elementum ex pellentesque et. Sed in blandit sapien. Integer vulputate ante id ipsum convallis, bibendum aliquam est gravida. In pretium dapibus massa, dictum finibus leo cursus mattis. Ut sit amet sagittis orci.\r\n\r\nDonec quis purus magna. Vestibulum vitae lorem ipsum. Praesent vitae mollis turpis. Integer finibus maximus consectetur. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia curae; Morbi tincidunt lacus sed interdum bibendum. Integer placerat urna a tellus dignissim, non tempor nisi efficitur. \r\n\r\n## Pellentesque ac metus\r\nEget quam fringilla congue sit amet eu nibh. Vivamus vulputate ligula sit amet libero ultrices, eu mattis ante tempor. Maecenas at lobortis ligula. Suspendisse vulputate ipsum magna, sed consectetur sapien ultricies ac. Nullam sem purus, euismod non nisi vel, iaculis hendrerit libero.', '2022-02-18 14:24:58', '2022-02-18 14:25:41');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `isAdmin` int(11) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `isAdmin`, `password`) VALUES
(8, 'Utilisateur', 'user@site.placeholder', 0, '$2y$10$AZ3qmA6opJNIxlyWLb9wS.DWM3mT7GseX5gOz42qFZLZPq3Meg0MK'),
(5, 'Admin', 'admin@site.placeholder', 1, '$2y$10$Gq.9IQNzqFbdrA14Y7R38.m1rNJMJpaTd2FWXwVDK.5H2abu4IwC2');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `authorId` (`authorId`),
  ADD KEY `postId` (`postId`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `authorId` (`authorId`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
